package com.cg.scoremanagement.dbconfig;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



/***********************************************************************************
 * - Class Name 		:-  DbUtil	
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	Get connection from DataSource "java:/jdbc/OracleDS" and return connection 
 **********************************************************************************/


public class DbUtil {

	
	static Connection con;
	
	public static Connection getConnection(){
		
		try{
		
		InitialContext ic;
			ic = new InitialContext();
		
		DataSource ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
		con = ds.getConnection();
		}
		catch(NamingException e){
			System.out.println(e.getMessage());
		}
		catch(SQLException e){

			System.out.println(e.getMessage());
		}
		
		return con;
	} 
	
}
