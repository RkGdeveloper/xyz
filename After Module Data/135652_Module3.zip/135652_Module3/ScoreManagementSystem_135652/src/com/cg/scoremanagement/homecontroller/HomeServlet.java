package com.cg.scoremanagement.homecontroller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;

import com.cg.scoremanagement.dto.TraineeDetails;
import com.cg.scoremanagement.scoreexception.ModuleScoreException;
import com.cg.scoremanagement.service.IScoreManagemenService;
import com.cg.scoremanagement.service.ScoreManagementServiceImpl;

/***********************************************************************************
 * - Class Name 		:-  HomeServlet
 * - Extends			:-  HttpServlet
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	This Class have all mapping logic and based on user 
 * 							input it will redirect to respective page
 **********************************************************************************/


@WebServlet("*.obj")
public class HomeServlet extends HttpServlet {
	
	Logger log = Logger.getLogger(HomeServlet.class); //create logger for class
	
	private static final long serialVersionUID = 1L;
       
	
	
	/***********************************************************************************
	 * - Function Name 		:-  doGet(HttpServletRequest request, HttpServletResponse response)
	 * - Input Parameters 	:-	HttpServletRequest request, HttpServletResponse response
	 * - Author 			:-	Govind Prajapati
	 * - Creation Date		:- 	11-10-2017
	 * - Description		:-	If request in doGet() then it will pass to doPost()
	 **********************************************************************************/
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	}

	
	
	
	/***********************************************************************************
	 * - Function Name 		:-  doPost(HttpServletRequest request, HttpServletResponse response)
	 * - Input Parameters 	:-	HttpServletRequest request, HttpServletResponse response
	 * - Author 			:-	Govind Prajapati
	 * - Creation Date		:- 	11-10-2017
	 * - Description		:-	doPost() have all mapping logic and if error or exception 
	 * 							are arrived then it will redirect to errorPage
	 **********************************************************************************/
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		IScoreManagemenService serviceRef = new ScoreManagementServiceImpl(); 		//service layer reference
		String target = null;
		String path = request.getServletPath();							 			// get path of servlet to map with other
		switch(path){
		
		
		// mapping for index.jsp on click on link
		
		case "/getAssessment.obj":{
			ArrayList<Integer> traineeIds;
		
			try {
				traineeIds = serviceRef.getAllTraineesId();				 			// get all trainee Id in ArrayList of Integer
				HttpSession session = request.getSession(true);						//session is created 
				session.setAttribute("traineeIds", traineeIds); 		 			// set list in session
				target = "pages/AddAssessment.jsp";						 			// redirected to AddAssessment.jsp page
			} 
			catch (ModuleScoreException e) {
				
				//if exception occurred then handle by ModuleScoreException error data set in error attribute in request scope
				
				request.setAttribute("error", e.getMessage());
				log.error(e.getMessage());
				target = "pages/ErrorPage.jsp";  						 			// redirected to ErrorPage.jsp page
			}
			
		}
		break;
		
		
		
		// mapping for submitting trainee data
		
		case "/addNewAssessment.obj":{
			request.setAttribute("error", null);
			
																		 			// get all parameter by request object
			
			int traineeId = Integer.parseInt(request.getParameter("traineeId"));
			String module_name = request.getParameter("module_name");

																		 			//check if details is exist or not in AssessmentScore Table
			if(serviceRef.isDetailsExist(traineeId,module_name) == false) 
			{
				int mptMarks = Integer.parseInt(request.getParameter("txtMptMarks"));
				int mttMarks = Integer.parseInt(request.getParameter("txtMttMarks"));
				int assignMarks = Integer.parseInt(request.getParameter("txtAssignMarks"));
	
				TraineeDetails traineeDto = new TraineeDetails();
				traineeDto.setTraineeId(traineeId);
				traineeDto.setModuleName(module_name);
				traineeDto.setMptMarks(mptMarks);
				traineeDto.setMttMarks(mttMarks);
				traineeDto.setAssignMarks(assignMarks);
				
				System.out.println(traineeDto);
				
				try {
					traineeDto =  serviceRef.insertTraineeDetails(traineeDto);  	//pass bean object to service layer and store return type in same DTO 
	
					HttpSession session = request.getSession(false); 
					session.setAttribute("dto", traineeDto);						// set DTO in session to print all the details
						
					target = "pages/ModuleScore.jsp";  								// redirected to ModuleScore.jsp page
						
				} catch (ModuleScoreException e) {
					request.setAttribute("error", e.getMessage());
					log.error(e.getMessage());
					target = "pages/ErrorPage.jsp";	 								// redirected to ErrorPage.jsp page
				}
		}//if closed
		else
		{
			String errorToShow = "Trainee Id and Score for that Module are already exist in table, please enter another details";
			request.setAttribute("error", errorToShow);
			log.error(errorToShow);
			target = "pages/AddAssessment.jsp";	  									// redirected to AddAssessment.jsp page
		}
			
		}
		break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
		
	}

}
