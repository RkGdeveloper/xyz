package com.cg.scoremanagement.dto;



/***********************************************************************************
 * - Class Name 		:-  TraineeDetails
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	This is bean class which have private data member and 
 * 							getter and setter to access those data.
 **********************************************************************************/



public class TraineeDetails {

	private int traineeId;
	private String moduleName;
	private double total;
	private int grade;
	private int mptMarks;
	private int mttMarks;
	private int assignMarks;
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getMptMarks() {
		return mptMarks;
	}
	public void setMptMarks(int mptMarks) {
		this.mptMarks = mptMarks;
	}
	public int getMttMarks() {
		return mttMarks;
	}
	public void setMttMarks(int mttMarks) {
		this.mttMarks = mttMarks;
	}
	public int getAssignMarks() {
		return assignMarks;
	}
	public void setAssignMarks(int assignMarks) {
		this.assignMarks = assignMarks;
	}
	
}
