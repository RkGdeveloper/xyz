package com.cg.scoremanagement.scoreexception;


/***********************************************************************************
 * - Class Name 		:-  ModuleScoreException
 * - Extends			:-  Exception
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	User defined Exception 
 **********************************************************************************/



public class ModuleScoreException extends Exception{

	private static final long serialVersionUID = 1L;

	public ModuleScoreException(String message){
		super(message);
	}
}
