package com.cg.scoremanagement.dao;

import java.util.ArrayList;
import com.cg.scoremanagement.dto.TraineeDetails;
import com.cg.scoremanagement.scoreexception.ModuleScoreException;


/***********************************************************************************
 * - Interface Name 	:-  IScoreManagementDAO
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	Interface for DAO Layer 
 **********************************************************************************/


public interface IScoreManagementDAO {

	ArrayList<Integer> getAllTraineesId() throws ModuleScoreException;

	TraineeDetails insertTraineeDetails(TraineeDetails traineeDto) throws ModuleScoreException;

	boolean isDetailsExist(int traineeId, String module_name);

	
}
