package com.cg.scoremanagement.service;

import java.util.ArrayList;

import org.jboss.resteasy.logging.Logger;

import com.cg.scoremanagement.dao.IScoreManagementDAO;
import com.cg.scoremanagement.dao.ScoreManagementDAOImpl;
import com.cg.scoremanagement.dto.TraineeDetails;
import com.cg.scoremanagement.scoreexception.ModuleScoreException;




/***********************************************************************************
 * - Class Name 		:-  ScoreManagementServiceImpl
 * - Interface Class 	:-	IScoreManagemenService			
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	Class create logger and call function from dao layer and return value to controller,
 * 							This class have function to calculate grade, Marks for given MPT,MTT and Assign in percentage,
 * 							and check whether data entered by user is already exist in table or not. 
 **********************************************************************************/


public class ScoreManagementServiceImpl implements IScoreManagemenService {

	Logger log = Logger.getLogger(ScoreManagementServiceImpl.class);
	
	IScoreManagementDAO daoRef = new ScoreManagementDAOImpl();
	
	@Override
	public ArrayList<Integer> getAllTraineesId() throws ModuleScoreException {
		log.info("Return all trainer Id to controller");
		return daoRef.getAllTraineesId();
	}

	@Override
	public TraineeDetails insertTraineeDetails(TraineeDetails traineeDto) throws ModuleScoreException {
		
		log.info("Insert Trainee details in AssessmentScore Table");
		
		double perMPT = calculateMarkForMPT(traineeDto);
		double perMtt = calculateMarkForMTT(traineeDto); 
		double perAssign = calculateMarkForAssign(traineeDto); 
		double total = perMPT+perMtt+perAssign;
		traineeDto.setTotal(total);
		
		int grade = calculateGrade(traineeDto);
		traineeDto.setGrade(grade);
		
		return daoRef.insertTraineeDetails(traineeDto);
	}

	
	
	private int calculateGrade(TraineeDetails traineeDto) {
		int grade =0;
		double total = traineeDto.getTotal();
		
		if(total > 0 && total < 49)
			grade = 0;
		else if(total < 59)
			grade = 1;
		else if(total < 69)
			grade = 2;
		else if(total < 79)
			grade = 3;
		else if(total < 89)
			grade = 4;
		else
			grade = 5;
		
		return grade;
	}

	private double calculateMarkForAssign(TraineeDetails traineeDto) {
		double per = 0.15;
		double perAssign = traineeDto.getAssignMarks() * per;
		return perAssign;
		
	}

	private double calculateMarkForMTT(TraineeDetails traineeDto) {
		
		double per = 0.15;
		double perMTT = traineeDto.getMttMarks() * per;
		return perMTT;
	}

	private double calculateMarkForMPT(TraineeDetails traineeDto) {
		double per = 0.75;
		double perMPT = traineeDto.getMptMarks() * per;
		return perMPT;
	}

	@Override
	public boolean isDetailsExist(int traineeId, String module_name) {
		
		
		return daoRef.isDetailsExist(traineeId,module_name);
	}
	
	

}
