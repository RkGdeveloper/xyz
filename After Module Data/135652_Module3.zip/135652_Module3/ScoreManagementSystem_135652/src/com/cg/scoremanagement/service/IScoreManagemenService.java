package com.cg.scoremanagement.service;

import java.util.ArrayList;

import com.cg.scoremanagement.dto.TraineeDetails;
import com.cg.scoremanagement.scoreexception.ModuleScoreException;


/***********************************************************************************
 * - Interface Name 	:-  IScoreManagementDAO
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	Interface for Service Layer 
 **********************************************************************************/

public interface IScoreManagemenService {

	ArrayList<Integer> getAllTraineesId() throws ModuleScoreException;

	TraineeDetails insertTraineeDetails(TraineeDetails traineeDto) throws ModuleScoreException;

	boolean isDetailsExist(int traineeId, String module_name);

	
}
