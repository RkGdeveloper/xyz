package com.cg.scoremanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.jboss.resteasy.logging.Logger;

import com.cg.scoremanagement.dbconfig.DbUtil;
import com.cg.scoremanagement.dto.TraineeDetails;
import com.cg.scoremanagement.scoreexception.ModuleScoreException;


/***********************************************************************************
 * - Class Name 		:-  ScoreManagementDAOImpl
 * - Interface Class 	:-	IScoreManagementDAO			
 * - Author 			:-	Govind Prajapati
 * - Creation Date		:- 	11-10-2017
 * - Version			:- 	1.0	
 * - Description		:-	Class create logger and run all database related query, return all trainer ids to service layer,
 * 							insert trainee details into table
 * 							and check whether data entered by user is already exist in table or not. 
 **********************************************************************************/


public class ScoreManagementDAOImpl implements IScoreManagementDAO {
	
	Logger log = Logger.getLogger(ScoreManagementDAOImpl.class);
	
	@Override
	public ArrayList<Integer> getAllTraineesId() throws ModuleScoreException {
		ArrayList<Integer> traineesIds = new ArrayList<Integer>();
		Connection con = DbUtil.getConnection();
		try {
			Statement st = con.createStatement();
			String sql = "Select trainee_Id from trainees";
		
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				traineesIds.add(rs.getInt(1));
			}
			log.info("Trainee Ids Sent to service layer");
			
			
		} catch (SQLException e) {
			log.error("In DAO Layer"+e.getMessage());
			throw new ModuleScoreException(e.getMessage());
		}
		return traineesIds;
	}

	
	@Override
	public boolean isDetailsExist(int traineeId, String module_name) {
		
		Connection con = DbUtil.getConnection();
		int nr = 0;
		try {
			PreparedStatement ps = con.prepareStatement("select * from assessmentscore where trainee_id = ? and module_name = ?");
			ps.setInt(1, traineeId);
			ps.setString(2, module_name);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				nr = rs.getInt(1);
			}
			if(nr == 0){
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return true;
	}
	

	@Override
	public TraineeDetails insertTraineeDetails(TraineeDetails traineeDto) throws ModuleScoreException {
		

		Connection con = DbUtil.getConnection();
		int numberOfRows =0;
			PreparedStatement pst;
			try {
				
				pst = con.prepareStatement("insert into assessmentscore values(?,?,?,?,?,?,?)");
				
				pst.setInt(1, traineeDto.getTraineeId());
				pst.setString(2, traineeDto.getModuleName());
				pst.setInt(3, traineeDto.getMptMarks());
				pst.setInt(4, traineeDto.getMttMarks());
				pst.setInt(5, traineeDto.getAssignMarks());
				pst.setDouble(6, traineeDto.getTotal());
				pst.setInt(7, traineeDto.getGrade());
				numberOfRows = pst.executeUpdate();
				System.out.println(numberOfRows+" row inserted");
				
				log.info(numberOfRows+" inserted in AssessmentScore Table");
			
				
			} catch (SQLException es) {
				log.error("In DAO Layer"+es.getMessage());
				throw new ModuleScoreException(es.getMessage());
			}
		
		return traineeDto;
	}


}
