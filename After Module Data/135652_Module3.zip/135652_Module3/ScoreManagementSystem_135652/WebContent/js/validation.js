function validate()
{
	var traineeId = document.forms[0].traineeId.value;
	var module_name = document.forms[0].module_name.value;
	var mptMarks = document.forms[0].mptMarks.value;
	var mttMarks = document.forms[0].mttMarks.value;
	var assignMarks = document.forms[0].assignMarks.value;
	
	
	if(traineeId == ""){
			alert('Please select Trainee Id Number'); 
			return false;
		}
	
	else if(module_name == ""){
			alert('please select Account Type'); 
			return false;
		}
	
	else if(mptMarks == "" || mttMarks == "" || assignMarks == ""){
		alert('Marks should not empty..');
		return false;
	}
	
	else if (mptMarks < 0 || mttMarks < 0 || assignMarks <0){		
		alert('Negative Marks is not allowed..');
		return false;
	}
	
	else if (mptMarks > 100 || mttMarks > 100 || assignMarks >100){		
		alert('Marks must be in range of 0 to 100');
		return false;
	}
	else
		return true;
	
	}

