package com.cg.bean;

public class Person {

	private String fName;
	private String lName;
	private char gender;
	Person()
	{}
	
	public Person(String fName, String lName, char gender) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.gender = gender;
	}
	
	
	@Override
	public String toString() {
		return "Person Details :\n-------------------- \nFirst Name : " + fName + " \nLast Name : " + lName + " \nGender : "
				+ gender;
	}


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}
	
	

	
}
