package com.cg.assignment4;

public class Account {

	private static long accNum = 10001021;
	private double balance;
	private Person accHolder;
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum() {
		Account.accNum = accNum+1;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	void deposite(double amt)
	{
		balance = balance + amt;
		
	}
	
	void withdraw(double amt)
	{
		balance = balance - amt;
	}
	
}
