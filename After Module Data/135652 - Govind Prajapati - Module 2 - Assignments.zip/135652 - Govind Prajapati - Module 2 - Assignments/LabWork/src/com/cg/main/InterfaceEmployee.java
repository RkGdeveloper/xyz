package com.cg.main;

interface InterfaceEmployee {

	void insert();
	void display();
	void retrieval();
	
}
