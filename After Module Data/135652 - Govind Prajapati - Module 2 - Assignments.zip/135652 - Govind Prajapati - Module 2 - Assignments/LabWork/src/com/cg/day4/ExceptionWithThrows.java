package com.cg.day4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class ExceptionWithThrows {

	public static void main(String[] args) throws ParseException {
		
		//String s = "10-12-2012"; // Exception in thread "main" java.text.ParseException: Unparseable date: "10-12-2012"
		String s = "10/12/2012";
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date d = sdf.parse(s);
		System.out.println(d);
		System.out.println("Excute");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate enteredDate = LocalDate.parse(s,formatter);

		System.out.println("Entered Date:"+ enteredDate);
		
	}
	
}
