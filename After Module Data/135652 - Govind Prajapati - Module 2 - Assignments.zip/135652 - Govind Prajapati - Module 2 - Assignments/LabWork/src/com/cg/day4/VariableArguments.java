package com.cg.day4;

public class VariableArguments {

	static void fun(int ...a)
	{
		for(int ad:a)
		System.out.println(ad);
		
	}
	
	
	public static void main(String[] args) {
		
		fun(110);
		fun(10,20,30);
		
	}
	
}
