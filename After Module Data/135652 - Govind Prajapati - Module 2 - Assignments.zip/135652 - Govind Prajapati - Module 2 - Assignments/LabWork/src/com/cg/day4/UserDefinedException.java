package com.cg.day4;

public class UserDefinedException {

	
	static void ageCheck(int age) throws AgeInvalidException
	{
		if(age < 18)
			throw new AgeInvalidException(age);
		else
			System.out.println("Age is "+age);
		
	}
	
	
	public static void main(String[] args) {
		
		try {
			ageCheck(2);
		} catch (AgeInvalidException e) {
			// TODO Auto-generated catch block
			System.out.println("User Defined Exception : "+e);
			//e.printStackTrace();
		}
	}
	
}



class AgeInvalidException extends Exception
{
	
	int age;
	AgeInvalidException(int age)
	{
		this.age = age;
	}
	@Override
	public String toString() {
		return "AgeInvalidException: Given " + age + " Age should be more than 18";
	}
	
}