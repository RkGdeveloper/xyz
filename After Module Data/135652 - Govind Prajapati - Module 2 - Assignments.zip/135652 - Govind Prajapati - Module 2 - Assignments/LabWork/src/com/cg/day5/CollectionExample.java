package com.cg.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class CollectionExample {

	public static void main(String[] args) {
	 ArrayListDetails ad = new ArrayListDetails(); // display duplicates element and preserve insert order 
		ad.acceptInput();
		
	/*	
		HashSetDetails hsd =  new HashSetDetails();  // display unique element and not preserve insert order 
		hsd.acceptInput();
		// if you want to preserve insertion order use linked hash set
	*/
		
	}
	
}
class HashSetDetails{
	
	void acceptInput()
	{
		HashSet<String> hs =  new HashSet<String>();
		
		hs.add("mno");
		hs.add("jkl");
		hs.add("abc");
		hs.add("jkl");
		hs.add(null);
		
		System.out.println("Hashset Data \n"+hs);
		
		LinkedHashSet<String> lhs =  new LinkedHashSet<String>();

		lhs.add("jkl");
		lhs.add("abc");
		lhs.add("mno");
		lhs.add("jkl");
		lhs.add(null);
		
		System.out.println("Linked Hash set Data \n"+lhs);
		
	}
	
}


class ArrayListDetails{
	
	void acceptInput(){
		ArrayList<Integer> a1 = new ArrayList<Integer>();
		a1.add(5);
		a1.add(8);
		a1.add(2);
		a1.add(6);
		a1.add(9);
		
		System.out.println("a1 \n"+a1);
		
		Collections.sort(a1);
		System.out.println("a1 Sorting \n"+a1);
		
		ArrayList<Integer> a2 = new ArrayList<Integer>();
		a2.add(1);
		a2.add(4);
		a2.add(7);
		a2.add(8);
		a2.add(6);
		
		System.out.println("a2 \n"+a2);
		
		a1.addAll(a2);
		System.out.println("After Merging \n"+a1);
		
		
		Collections.sort(a1);
		System.out.println("Sorted Element \n"+a2);
		
		/*
		a1.retainAll(a2);
		System.out.println("Retain All \n"+a1);
		
		System.out.println(a1.size());
		
		System.out.println("Element Present in a2 using For each");
		for(Integer el : a2)
			System.out.println(el);
		
		System.out.println("Element Present in a2 Using Iterator");
		
		*/
		ArrayList<Integer> a3 = new ArrayList<Integer>();
		a3.add(a1.get(2));
		a3.add(a1.get(4));
		a3.add(a1.get(6));
		System.out.println("a3 elements \n"+a3);

		
		Iterator<Integer> itr = a1.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}
}