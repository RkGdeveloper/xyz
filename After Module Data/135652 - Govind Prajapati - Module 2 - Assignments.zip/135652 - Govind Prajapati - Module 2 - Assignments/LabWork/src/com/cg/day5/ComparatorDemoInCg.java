package com.cg.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorDemoInCg {

	public static void main(String[] args) {
		
		ArrayList<Empp> al = new ArrayList<Empp>();
		al.add(new Empp(101,"Govind",25000));
		al.add(new Empp(103,"Shubham",15000));
		al.add(new Empp(102,"Harshal",35000));
		
		System.out.println("Sort by Emp id");
		Collections.sort(al,new SortByEmpId());
		for(Empp e : al)
		{
			System.out.println(e);
			
		}
		
		System.out.println("Sort by Emp Sal");
		Collections.sort(al,new SortByEmpId());
		for(Empp e : al)
		{
			System.out.println(e);
			
		}
		
	}
	
}


class SortByEmpId implements Comparator<Empp>{

	@Override
	public int compare(Empp o1, Empp o2) {
		// TODO Auto-generated method stub
		return o1.getEmpId() - o2.getEmpId();
	}

}


class SortByESal implements Comparator<Empp>{

	@Override
	public int compare(Empp o1, Empp o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getEmpSal() - o2.getEmpSal());
	}
	
	
}


class Empp{
	
	int empId;
	String empName;
	double empSal;
	
	
	
	public Empp(int empId, String empName, double empSal) {
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}


	@Override
	public String toString() {
		return "Empp [empId=" + empId + ", empName=" + empName + ", empSal="
				+ empSal + "]";
	}
	
	
}