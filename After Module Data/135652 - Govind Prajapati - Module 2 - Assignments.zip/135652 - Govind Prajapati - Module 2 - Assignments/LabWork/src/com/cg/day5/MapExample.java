package com.cg.day5;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class MapExample {

	public static void main(String[] args) {
	/*	HashMapDetails md  = new HashMapDetails();
		md.mapInput();
		
	*/	TreeMapDetails tm = new TreeMapDetails();
		tm.treeMapInput();
	}
	
	
}


class HashMapDetails{
	
	void mapInput(){
		
		HashMap<Integer,String> hm = new HashMap<Integer, String>();

		hm.put(103,"Harshal");
		hm.put(124,"Pankanj");
		hm.put(201,"Govind");
		hm.put(102,"Subham");
		hm.put(110,null);
		
		
		System.out.println("Normal As Object"+hm);
		
		
		System.out.println("\n\nUsing for each with entry set");
		for(Map.Entry<Integer, String> out : hm.entrySet())
		{
			
			Integer key = out.getKey();
			String value = out.getValue();
			
			System.out.println(key+ " = > "+value);
		}
		
		
		System.out.println("\n\nUsing Iterator");
		Iterator<Integer> itr = hm.keySet().iterator();
		while(itr.hasNext())
		{
			Integer key = itr.next();
			String value = hm.get(key);
			System.out.println(key+" = > "+value);
			
		}
		
		
	}
	
	
	
}






class TreeMapDetails{
	
	void treeMapInput(){
		
		TreeMap<Integer,String> hm = new TreeMap<Integer, String>();

		hm.put(103,"Harshal");
		hm.put(124,"Pankanj");
		hm.put(201,"Govind");
		hm.put(102,"Subham");
		hm.put(110,null);
		System.out.println("Normal As Object"+hm);
		
		
		System.out.println("\n\nUsing for each with entry set");
		for(Map.Entry<Integer, String> out : hm.entrySet())
		{
			
			Integer key = out.getKey();
			String value = out.getValue();
			
			System.out.println(key+ " = > "+value);
		}
		
		
		System.out.println("\n\nUsing Iterator");
		Iterator<Integer> itr = hm.keySet().iterator();
		while(itr.hasNext())
		{
			Integer key = itr.next();
			String value = hm.get(key);
			System.out.println(key+" = > "+value);
			
		}
		
		
	}
	
	
	
}