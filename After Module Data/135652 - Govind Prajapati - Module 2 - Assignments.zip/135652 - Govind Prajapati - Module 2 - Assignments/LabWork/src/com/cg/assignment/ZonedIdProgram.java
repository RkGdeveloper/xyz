package com.cg.assignment;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZonedIdProgram {

	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Zone Id");
		String zoneId = sc.nextLine();
		ZonedTime zt = new ZonedTime();
		
		ZonedDateTime currentTime =  zt.getZooned(zoneId);
		
		System.out.println("Current Time in : "+zoneId + " is "+ currentTime);
		
	}
}


class ZonedTime
{
	 public ZonedDateTime getZooned(String Zone)
	 {
		 
		 return(ZonedDateTime.now(ZoneId.of(Zone)));
	 }
}
