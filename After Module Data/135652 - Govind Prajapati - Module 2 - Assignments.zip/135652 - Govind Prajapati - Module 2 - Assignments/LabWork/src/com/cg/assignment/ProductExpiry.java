package com.cg.assignment;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ProductExpiry {

	public static void main(String[] args) {
	
			/*	DateTimeFormatter is used to configure the date time format
				DateTimeFormatter can also be obtained by using ofPattern() 
				which you can use for custom date and time format
			 */
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = sc.nextLine();
			
			//Almost every class in java.time package provides parse() method to parse the date or time
			LocalDate enteredDate = LocalDate.parse(input,formatter);
			
			

			System.out.println("Entered Date:"+ enteredDate);
			int day = enteredDate.getDayOfMonth();
			int month = enteredDate.getMonthValue();
			int year = enteredDate.getYear();
			
			System.out.println("Enter months warrantee ");
			int  wMonth = month +  sc.nextInt();
			System.out.println("Enter years warrantee ");
			int wYear = year + sc.nextInt();
		
			if(wMonth > 12)
			{
				wYear = wYear + 1;
				wMonth = wMonth - 12;
			}
			
			System.out.println("Product Expiry Date : ");
			System.out.println("Day : "+day);
			System.out.println("Month : "+wMonth);
			System.out.println("Year : "+wYear);
			
			
			
			sc.close();
	}
}


