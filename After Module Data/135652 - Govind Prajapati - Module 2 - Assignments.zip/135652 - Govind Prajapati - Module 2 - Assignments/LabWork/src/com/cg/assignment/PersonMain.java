package com.cg.assignment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		Person p = new Person();
		System.out.println("Enter First name : ");
		p.setFname(sc.next());
		
		System.out.println("Enter Last name : ");
		p.setLname(sc.next());
		
		System.out.println("Enter Gender: ");
		char g = sc.next().charAt(0);
		if(g == 'M' || g == 'F')
		{
		p.setGender(g);
			
		System.out.println("Enter PhoneNumber: ");
		p.setPhonenumber(sc.nextLong());
		sc.nextLine();
		
		System.out.println("Enter Date of Birth in MM/dd/yyyy format");
		String dob = sc.nextLine();
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		Date d1 = null;
		Calendar cal = Calendar.getInstance();
	    Date d2=cal.getTime();
		
		try {
			d1 = format.parse(dob);
			long d = d2.getTime()-d1.getTime();
			
			
			
			long diffDays = d / (24 * 60 * 60 * 1000);
			long years = diffDays / 365;
			
			p.setAge(years);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		printDetails(p);
		}
		else
			System.out.println("Input must be M/F");
		
	}	
	
	static void printDetails(Person p)
	{

		System.out.println("Person Details\n----------------");
		System.out.println("First Name : "+p.getFname());
		System.out.println("Last Name : "+p.getLname());
		System.out.println("Gender Name : "+p.getGender());
		System.out.println("Phone Number : "+p.getPhonenumber());

		System.out.println("Age is : "+p.getAge());
	}
}
