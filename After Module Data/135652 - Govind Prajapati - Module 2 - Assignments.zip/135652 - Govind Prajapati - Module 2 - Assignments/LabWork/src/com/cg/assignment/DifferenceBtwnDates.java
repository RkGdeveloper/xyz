package com.cg.assignment;


import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Scanner;

public class DifferenceBtwnDates {

	public static void main(String[] args) {
		DateDiff df = new DateDiff();
		df.getDate();
		
	}
	
}


class DateDiff
{
	Scanner sc = new Scanner(System.in);
	
	void getDate()
	{
		
		System.out.print("Enter Date 1 in MM/dd/yyyy format:");
		String dateStart  = sc.nextLine();
		System.out.print("Enter Date 2 in MM/dd/yyyy format:");
		String dateStop  = sc.nextLine();
		
/*		String dateStart = "01/14/2012 09:29:58";
		String dateStop = "01/15/2013 10:31:48";

		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
*/
/*		
		String dateStart = "01/14/2012";
		String dateStop = "01/15/2013";

*/		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();
/*
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;*/
			long diffDays = diff / (24 * 60 * 60 * 1000);
			double months = diffDays / 31;
			double years = diffDays / 365;
			
			System.out.print(diffDays + " days\n ");
			System.out.print(months + " months\n");
			System.out.print(years + " years\n");
			
			/*
			System.out.print(diffHours + " hours, ");
			System.out.print(diffMinutes + " minutes, ");
			System.out.print(diffSeconds + " seconds.");
*/
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
}