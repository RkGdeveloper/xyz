package com.cg.day2;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DateFunctions {

	
	public static void main(String[] args) {
		/*
		LocalDate d = LocalDate.now();
		LocalDate d1 =LocalDate.of(2016,03,20);
		
		System.out.println(d);
		System.out.println(d1);
		System.out.println(d.getYear());
		System.out.println(d.getMonth());
		System.out.println(d.getDayOfMonth());
		System.out.println(d.plusDays(2));
	
		DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dd = "12/02/2015";
		LocalDate ddd = LocalDate.parse(dd,f);
		System.out.println(ddd);
	*/
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter date in dd-MM-yyyy format:");
		String input  = scanner.nextLine();
		
		//Almost every class in java.time package provides parse() method to parse the date or time
		LocalDate enteredDate = LocalDate.parse(input,formatter);

		System.out.println("Entered Date:"+ enteredDate);
		scanner.close();
	
	
	}
	
}
