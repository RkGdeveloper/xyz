package com.cg.day2;

enum directions{
	SOUTH,NORTH,EAST,WEST;
}

public class EnumExample {
	public static void main(String[] args) {
		System.out.println(directions.NORTH);
		System.out.println(directions.SOUTH);
		
		System.out.println("/***Print all the values of ENUM***/");
		
		for(directions s:directions.values())
				System.out.println(s);
		
	}
}
