package com.cg.stream_api;

public class StreamAPI_Main {

	public static void main(String[] args) {
		

		
		
	}
	
}
