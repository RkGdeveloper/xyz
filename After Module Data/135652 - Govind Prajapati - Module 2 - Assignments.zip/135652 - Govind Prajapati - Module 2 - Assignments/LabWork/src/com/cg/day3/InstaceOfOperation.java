package com.cg.day3;

class Employee
{
	
String empName = "Govind";	
	
	void getEmployee()
	{
		System.out.println("In Super Employee");
		
	}

}

class Programmer extends Employee
{
	
String data = super.empName;

	void getProgram()
	{
		
		System.out.println("In Sub Programmer "+super.empName);
	
	}
	
	

}


class Tester 
{
	Tester()
	{
		
		System.out.println("Constructor");
	}
}

public class InstaceOfOperation {

	public static void main(String[] args) {
		
		Programmer p = new Programmer();
		p.getEmployee();
		p.getProgram();
		
		Tester t =  new Tester();
		
		System.out.println(p instanceof Employee);
		System.out.println(t instanceof Object);
		/*
		System.out.println(t instanceof Employee); it cannot take this show compile time error*/

		
	}
	
}
