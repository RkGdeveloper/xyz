package com.cg.day3;

interface Vehicle
{
	void disply();
	void break_vehicle();
	
	// java 1.8 come up with implementation in interface with default and static 
	// default can be access by creating 
	default void getVehicle()
	{
		System.out.println("In Vehicle Interface in default method getVehicle() function ");
	}
}

interface Branding{
	
	String brandName="Hero";
	void getBrandName();
}


public class InterfaceOpeartions {

	public static void main(String[] args) {
		
		Bike b = new Bike();
		b.disply();
		b.break_vehicle();
		b.getBrandName();
		b.getVehicle(); // access interface method with Object
		
	}
	
}


class Bike implements Vehicle,Branding
{

	@Override
	public void disply() {
		// TODO Auto-generated method stub
		
		System.out.println("Display in Bike Class");
		
	}

	@Override
	public void break_vehicle() {
		// TODO Auto-generated method stub
		
		System.out.println("Break in Break_vehicle");
	}

	@Override
	public void getBrandName() {
		// TODO Auto-generated method stub
		System.out.println("Brand Name is "+brandName);
	}
	
}