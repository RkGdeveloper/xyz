package com.cg.day3;

public class OverloadingOperations {

	public static void main(String[] args) {
		
		OverloadingFunctions of =  new OverloadingFunctions();
		
		System.out.println(of.sum(10, 20));
		System.out.println(of.sum(10.20,20.85));
		System.out.println(of.sum(10,20,50));
		
	}
	
	
}


class OverloadingFunctions
{
	int sum(int a,int b)
	{
		return a+b;
	}
	int sum(int a,int b,int c)
	{
		return a+b+c;
	}
	double sum(double a,double b)
	{
		return a+b;
	}
}