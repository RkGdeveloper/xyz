package com.cg.day1;

import java.util.Scanner;

public class EmployeeDetails {

	int empId;
	String empName;
	float esalary;
	char grade;
	long phonenumber;
	
	Scanner sc = new Scanner(System.in);
	
	void setEmpDetaiils()
	{
		System.out.println("Enter Emp Id");
		empId= sc.nextInt();
		System.out.println("Enter Emp Name");
		empName = sc.next();
		System.out.println("Enter Emp Salary");
		esalary = sc.nextFloat();
		System.out.println("Enter Emp Grade");
		grade = sc.next().charAt(0);
		System.out.println("Enter Emp Phone Number");
		phonenumber = sc.nextLong();		
		
	}
	
	void printEmpDetails()
	{
		System.out.println("Enter Emp Id "+empId);
		
		System.out.println("Enter Emp Name "+empName);
		
		System.out.println("Enter Emp Salary "+esalary);
		
		System.out.println("Enter Emp Grade "+grade);
		
		System.out.println("Enter Emp Phone Number "+phonenumber);
		
	}
	
	
}
