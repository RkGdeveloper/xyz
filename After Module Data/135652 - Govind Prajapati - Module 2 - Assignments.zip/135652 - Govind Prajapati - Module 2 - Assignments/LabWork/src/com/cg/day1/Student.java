package com.cg.day1;

public class Student {

	int studId;
	String studName;
	static String collegeName = "KJ Somiya"; // common for all object
	static String Dept;
	
	
	Student(int s_id,String s_name)
	{
		studId = s_id;
		studName = s_name;
		
	}
	
	void display()
	{
		
		System.out.println("Student Id : "+studId);
		System.out.println("Student Name : "+studName);
		System.out.println("Student College : "+collegeName);
		System.out.println("Student Department : "+Student.Dept);
		System.out.println("-----------------------------------");
	}
	
	static void setDept(String d) //static method to set dept
	{
		
		Dept = d;
	}
}

