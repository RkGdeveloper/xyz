package com.cg.day1;

import java.util.Scanner;

public class PersnalDetails {

	public static void main(String[] args) {
		Persnal p = new Persnal();
		p.getPersnalDetails();
		p.printDetails();
		
	}
	
}


class Persnal
{

	Scanner sc = new Scanner(System.in);
	
	String fname,lname;
	char gender;
	int age;
	float weight;
	
	void getPersnalDetails()
	{
		
		System.out.println("Enter First name");
		fname = sc.next();
		System.out.println("Enter Last name");
		lname = sc.next();
		System.out.println("Enter Gender");
		gender = sc.next().charAt(0);
		
		System.out.println("Enter Age");
		age = sc.nextInt();
		System.out.println("Enter Weight");
		weight = sc.nextFloat();
		
	}
	
	void printDetails()
	{
		System.out.println("Person Details:\n-----------------");
		System.out.println("First name "+fname);
		
		System.out.println("Last name: "+lname);
		
		System.out.println("Gender: "+gender);
		
		
		System.out.println("Age: "+age);
		
		System.out.println("Weight: "+weight);
		
		
	}
	
}
