package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.exceptions.MobileApplicationException;

public interface IMobileService {

	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException;
	public ArrayList<Mobile> getAllMobileDetails() throws IOException, SQLException;
	
	public boolean validateName(String name);
	public boolean validateEmail(String email);
	public boolean validatePhone(String phoneno);
	public boolean validatMobileId(String mobileId) throws IOException, SQLException;
}
