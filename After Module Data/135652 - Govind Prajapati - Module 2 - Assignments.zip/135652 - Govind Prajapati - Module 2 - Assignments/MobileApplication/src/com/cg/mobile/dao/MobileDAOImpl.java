package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.databaseconfig.DbUtil;
import com.cg.mobile.exceptions.MobileApplicationException;

public class MobileDAOImpl implements IMobileDAO{
	
	Logger log = Logger.getRootLogger();
	
	public MobileDAOImpl(){
		PropertyConfigurator.configure("log4j.properties");
	
	}
	
	int numRows;
	@Override
	public int addPurchaseDetailsToDAO(PurchaseDetails p) throws MobileApplicationException {
		// TODO Auto-generated method stub
	
		
		try {
			Connection con =  DbUtil.getConnection();
			
			String insertQ = "INSERT INTO PurchaseDetails Values(purchase_seq_id.nextval,?,?,?,SYSDATE,?)";
			PreparedStatement ps = con.prepareStatement(insertQ);
			ps.setString(1, p.getCname());
			ps.setString(2, p.getMailId());
			ps.setLong(3,p.getPhoneNo());
			ps.setInt(4, p.getMobileId());
			
			/*String mobiledata = "SELECT mobileid from mobiles Where mobileid = ?";
			PreparedStatement pst = con.prepareStatement(mobiledata);
			int mob_id;
			pst.setInt(1,p.getMobileId());
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("Mobile Id is "+(mob_id = rs.getInt(1)));
				ps.setInt(4, mob_id);
			}*/
			
			numRows = ps.executeUpdate();
			log.info("Data Inserted Successfully");
			
			
		}
		catch (IOException | SQLException e) {
			String str = e.getMessage();
			log.error(str);
			throw new MobileApplicationException(e.getMessage());
		}
		
		
		
		return numRows;
	}
	@Override
	public int checkMobileIdInTable(String mobileId) throws IOException, SQLException {
		// TODO Auto-generated method stub
		
		Connection con =  DbUtil.getConnection();
		String str = "Select * from Mobiles where mobileid = ?";
		PreparedStatement st = con.prepareStatement(str);
		int res = st.executeUpdate();
		return res;
		
	}
	@Override
	public ArrayList<Mobile> getAllMobiles() throws IOException, SQLException {
		
		Connection con = DbUtil.getConnection();
		String str = "Select * from mobiles";
		
		ArrayList<Mobile> mal = new ArrayList<Mobile>();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(str);
		
		while(rs.next())
		{
			int mobId = rs.getInt(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			String quan = rs.getString(4);
			mal.add(new Mobile(mobId,name,price,quan));		
		}
		
		return mal;

	}

	
	
}
