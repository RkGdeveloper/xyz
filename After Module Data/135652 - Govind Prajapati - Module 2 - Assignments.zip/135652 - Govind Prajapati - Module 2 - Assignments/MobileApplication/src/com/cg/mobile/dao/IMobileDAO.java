package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.exceptions.MobileApplicationException;

public interface IMobileDAO {

	public int addPurchaseDetailsToDAO(PurchaseDetails p) throws MobileApplicationException;

	public int checkMobileIdInTable(String mobileId) throws IOException, SQLException;

	public ArrayList<Mobile> getAllMobiles() throws IOException, SQLException;
	
}
