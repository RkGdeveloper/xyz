package com.cg.mobile.tesejunit;


import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.dao.IMobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.exceptions.MobileApplicationException;


public class MobileApplicationTestCase {

	static IMobileDAO mob = null;
	static PurchaseDetails pd = null;
@BeforeClass

	public static void initialize() 
	{
	System.out.println("Hello ");
	mob = new MobileDAOImpl();
	pd = new PurchaseDetails();
	}

@Test
public void testData(){
	pd.setCname("Amnmjk");
	pd.setMailId("xyz@gmail.com");
	pd.setMobileId(1009);
	pd.setPhoneNo(788784512);
	pd.setPurchaseId(123);
}
@Test
public void testAddDetails()   {
	try {
		assertNotNull(mob.addPurchaseDetailsToDAO(pd));
	} catch (MobileApplicationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

@Test
public void testGetDetails() throws IOException, SQLException {
	assertNotNull(mob.getAllMobiles());
	}



}
