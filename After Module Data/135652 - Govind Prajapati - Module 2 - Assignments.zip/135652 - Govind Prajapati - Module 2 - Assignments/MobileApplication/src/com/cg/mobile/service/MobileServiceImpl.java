package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.bean.PurchaseDetails;
import com.cg.mobile.dao.IMobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.exceptions.MobileApplicationException;

public class MobileServiceImpl implements IMobileService{

	IMobileDAO imd = new MobileDAOImpl();
	
	@Override
	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException {
		// TODO Auto-generated method stub
		
			int numOfRows = imd.addPurchaseDetailsToDAO(p);
		
		return numOfRows;
	}
	
	

	public boolean validateName(String name){
		
		String ptrn = "[A-Z]{1}[a-z]{2,19}";
		if(Pattern.matches(ptrn, name)){
			
			return true;
		}
		else
		{
			System.out.println("Please enter the Correct Name");
			return false;
		}
	}
	
	public boolean validateEmail(String email){
		
		String ptrn = "^[?=.*A-Za-z0-9]+@[A-Za-z]+\\.[A-Za-z]{2,6}$";
		if(Pattern.matches(ptrn, email)){
			
			return true;
		}
		else
		{
			System.out.println("Please enter the Correct Email");
			return false;
		}
	}


	public boolean validatePhone(String phoneno){
	
	String ptrn = "[0-9]{10}";
	if(Pattern.matches(ptrn, phoneno)){
		
		return true;
	}
	else
		{
		System.out.println("Please enter the Correct Phoneno");
		return false;
		}
	}
	
	
	public boolean validatMobileId(String mobileId) throws IOException, SQLException{
		String ptrn = "[0-9]{4}";
		if(Pattern.matches(ptrn, mobileId)){
			int res = 0;
			/*res = imd.checkMobileIdInTable(mobileId);
			if(res == 0)
				return false;
			else*/
			return true;
			
		}
		else
			{
			System.out.println("Please enter the Correct Phoneno");
			return false;
			}
		
	}



	@Override
	public ArrayList<Mobile> getAllMobileDetails() throws IOException, SQLException {
		
		
		
		return imd.getAllMobiles();
	}
		

}
