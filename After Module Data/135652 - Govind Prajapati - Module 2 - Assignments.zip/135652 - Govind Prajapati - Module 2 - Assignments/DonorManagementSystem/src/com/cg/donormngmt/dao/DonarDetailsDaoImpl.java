package com.cg.donormngmt.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.donormngmt.bean.Donor;
import com.cg.donormngmt.dbconfig.DbUtil;

public class DonarDetailsDaoImpl implements IDonarDetailsDao{

	@Override
	public ArrayList<Donor> getAllDonor() throws IOException, SQLException {
		
		ArrayList<Donor> al =  new ArrayList<Donor>();
		Connection con = DbUtil.getConnection();
		
		String sql =  "Select * from DonarDetails";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while(rs.next())
		{
			String d_id =rs.getString(1);
			String d_name = rs.getString(2);
			String d_phone = rs.getString(3);
			String d_address = rs.getString(4);
			double d_amt = rs.getLong(5);
			String d_date = rs.getString(6);
			al.add(new Donor(d_id,d_name,d_phone,d_address,d_amt,d_date));
			
		}
		
		return al;
	}

	@Override
	public int insertDonor(Donor d) throws SQLException, IOException {
	
		Connection con = DbUtil.getConnection();
		
		String sql =  "insert into DonarDetails values(donor_seq_id.nextval,?,?,?,?,Sysdate)";
		PreparedStatement pst = con.prepareStatement(sql);
		
		pst.setString(1, d.getDonarName());
		pst.setString(2, d.getdPhoneNo());
		pst.setString(3, d.getdAddress());
		pst.setDouble(4,d.getDonationAmt());
		
		
		int nr = pst.executeUpdate();
		
		return nr;
	}

}
