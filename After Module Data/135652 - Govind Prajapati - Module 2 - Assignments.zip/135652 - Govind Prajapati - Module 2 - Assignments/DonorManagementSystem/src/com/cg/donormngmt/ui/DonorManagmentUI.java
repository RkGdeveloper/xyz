package com.cg.donormngmt.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.donormngmt.bean.Donor;
import com.cg.donormngmt.service.DonarDetailsOperationImpl;
import com.cg.donormngmt.service.IDonarDetailsOperation;

public class DonorManagmentUI {

	public static void main(String[] args) throws IOException, SQLException {
		
		Scanner sc = new Scanner(System.in);
		
		DonorManagmentUI di = new DonorManagmentUI();
		
		while(true)
		{
		System.out.println("Enter Your Choice : \n1.Insert Donar Details \n2.Get All Donor Details\n3.Exit\n");
		int choice = sc.nextInt();
			switch(choice){
			case 1:
				di.insertDonorDetails();
			break;
			case 2:
				di.getAllDetails();
			break;
			case 3:
				System.exit(0);
			}
		if(choice == 3)
			break;
		}
		
		System.out.println("Thank you");
	}
	
	
	private void insertDonorDetails() throws SQLException, IOException {
		Scanner sc = new Scanner(System.in);
		IDonarDetailsOperation ido = new DonarDetailsOperationImpl();
		Donor d = new Donor();
		
		
		System.out.println("Enter Name of Donor : ");
		d.setDonarName(sc.next());
		System.out.println("Enter Phone Number : ");
		d.setdPhoneNo(sc.next());
		System.out.println("Enter Address of Donor : ");
		d.setdAddress(sc.next());
		System.out.println("Enter Donation Amount  : ");
		d.setDonationAmt(sc.nextDouble());
		int nr = ido.insertDonorDetails(d);
		
		System.out.println(nr+" row inserted");
		
	}


	void getAllDetails() throws IOException, SQLException
	{
		IDonarDetailsOperation ido = new DonarDetailsOperationImpl();
		
		ArrayList<Donor> al = ido.getAllDonarDetails();
		for(Donor d :al)
		{
			System.out.println(d);
			
		}
		
	}
	
	
	
}
