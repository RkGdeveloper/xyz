package com.cg.donormngmt.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donormngmt.bean.Donor;
import com.cg.donormngmt.dao.DonarDetailsDaoImpl;
import com.cg.donormngmt.dao.IDonarDetailsDao;

public class DonarDetailsOperationImpl implements IDonarDetailsOperation{

	@Override
	public ArrayList<Donor> getAllDonarDetails() throws IOException, SQLException {
		IDonarDetailsDao idd = new DonarDetailsDaoImpl(); 
		
		return idd.getAllDonor();
	}

	@Override
	public int insertDonorDetails(Donor d) throws SQLException, IOException {
		// TODO Auto-generated method stub
		IDonarDetailsDao idd = new DonarDetailsDaoImpl(); 
		return idd.insertDonor(d);
	}

}
