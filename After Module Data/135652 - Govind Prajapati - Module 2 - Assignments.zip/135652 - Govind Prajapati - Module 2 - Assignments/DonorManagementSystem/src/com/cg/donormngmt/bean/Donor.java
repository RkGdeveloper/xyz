package com.cg.donormngmt.bean;

import java.time.LocalDate;

public class Donor {

	private String donorId;
	private String donarName;
	private String dPhoneNo;
	private String dAddress;
	private double donationAmt;
	private String donationDate;
	
	
	public String getDonorId() {
		return donorId;
	}
	public void setDonorId(String donorId) {
		this.donorId = donorId;
	}
	public String getDonarName() {
		return donarName;
	}
	public void setDonarName(String donarName) {
		this.donarName = donarName;
	}
	public String getdPhoneNo() {
		return dPhoneNo;
	}
	public void setdPhoneNo(String dPhoneNo) {
		this.dPhoneNo = dPhoneNo;
	}
	public String getdAddress() {
		return dAddress;
	}
	public void setdAddress(String dAddress) {
		this.dAddress = dAddress;
	}
	public double getDonationAmt() {
		return donationAmt;
	}
	public void setDonationAmt(double donationAmt) {
		this.donationAmt = donationAmt;
	}
	public String getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(String donationDate) {
		
		
		
		this.donationDate = donationDate ;
	}
	public Donor(String donorId, String donarName, String dPhoneNo,
			String dAddress, double donationAmt,String donationDate) {
		super();
		this.donorId = donorId;
		this.donarName = donarName;
		this.dPhoneNo = dPhoneNo;
		this.dAddress = dAddress;
		this.donationAmt = donationAmt;
		this.donationDate = donationDate;
	}
	public Donor(){}
	
	@Override
	public String toString() {
		return "Donor Details :\n donorId=" + donorId + "\n donarName=" + donarName
				+ "\n dPhoneNo=" + dPhoneNo + "\n dAddress=" + dAddress
				+ "\n donationAmt=" + donationAmt + "\n donationDate="
				+ donationDate + "]";
	}
	
	
}
