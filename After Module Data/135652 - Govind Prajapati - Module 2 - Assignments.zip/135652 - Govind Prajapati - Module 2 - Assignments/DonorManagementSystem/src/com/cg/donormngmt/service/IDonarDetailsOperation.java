package com.cg.donormngmt.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donormngmt.bean.Donor;

public interface IDonarDetailsOperation {

	public ArrayList<Donor> getAllDonarDetails() throws IOException, SQLException;

	public int insertDonorDetails(Donor d) throws SQLException, IOException;
	
}
