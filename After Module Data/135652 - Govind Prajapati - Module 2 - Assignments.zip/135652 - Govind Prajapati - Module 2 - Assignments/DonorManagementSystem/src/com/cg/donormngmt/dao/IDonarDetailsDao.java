package com.cg.donormngmt.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donormngmt.bean.Donor;

public interface IDonarDetailsDao {

	public ArrayList<Donor> getAllDonor() throws IOException, SQLException;

	public int insertDonor(Donor d) throws SQLException, IOException;
	
	
}
