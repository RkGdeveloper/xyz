package com.cg.userinterctions;

import com.cg.acct.Account;
import com.cg.person.Person;

public class UserDetails {

public static void main(String[] args) {
		
	Person p1 = new Person();
	Person p2 = new Person();
	Account sm = new Account();
	Account kt = new Account();
	
	sm.setAccHolder(p1);
	p1 = sm.getAccHolder();
	
	
	// a) Create Account for smith with initial balance as INR 2000 and for Kathy with initial balance as 3000.
	p1.setName("Smith");
	p1.setAge(22); // accNum should be auto generated
	sm.setBalance(2000);
	Account.setAccNum();
	System.out.println(sm.toString(sm));
	
	
	kt.setAccHolder(p2);
	p2 = kt.getAccHolder();
	
	p2.setName("Kathy");
	p2.setAge(21); // accNum should be auto generated
	Account.setAccNum();
	kt.setBalance(3000);
	
	System.out.println(kt.toString(kt));
	
	
	// b) Deposit 2000 INR to smith account.
	sm.deposite(2000);
	System.out.println(sm.toString(sm));
	
	// c) Withdraw 2000 INR from Kathy account.
	
	kt.withdraw(2000);
	System.out.println(kt.toString(kt));
	kt.withdraw(1500);// print insufficient balance
	
	}
}
