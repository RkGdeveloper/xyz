package com.cg;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcWithProperties {

	public static void main(String[] args) throws IOException, SQLException {
		
		Connection con = DbUtil.getConnection();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * From empl");
		while(rs.next())
		{
			System.out.println("Emp Id : "+rs.getInt(1)+"\n"+"Emp Name :"+rs.getString(2)+"\n\n");
			
		}
		con.close();
		
	}
	
}
