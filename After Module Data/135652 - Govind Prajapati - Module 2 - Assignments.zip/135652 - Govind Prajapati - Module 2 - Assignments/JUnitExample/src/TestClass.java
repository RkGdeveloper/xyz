import static org.junit.Assert.*;

import org.junit.Test;


public class TestClass {

	
	@Test
	public void test(){
		
		Calculator c =new Calculator();
		int res = c.add(2,4);
		assertEquals(6,res); //assertEquals(actualResult,actualResult);
	}

}
