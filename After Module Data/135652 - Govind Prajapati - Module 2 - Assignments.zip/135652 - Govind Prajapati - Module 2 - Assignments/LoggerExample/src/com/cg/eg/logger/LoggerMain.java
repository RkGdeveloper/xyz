package com.cg.eg.logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoggerMain {

	public static void main(String[] args) {
		
		
		PropertyConfigurator.configure("log4j.properties");
		Logger log = Logger.getRootLogger();
		try{
			String s = "abc123";
			int a = Integer.parseInt(s);
			log.info("Executed Successfully");
			
		}
		catch(Exception e){
			log.error("Exception Occured : "+e.getMessage());
		}
		
	}
	
}
