package com.cg.acct;

import com.cg.person.Person;

public class Account extends Person{

	private static long accNum = 1081810;
	private double balance;
	private Person accHolder;
	
	public long getAccNum() {
		return accNum;
	}
	public static void setAccNum() {
		Account.accNum ++ ;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposite(double amt)
	{
		balance = balance +amt;
		setBalance(balance);
	}
	public void withdraw(double amt)
	{
		
		if(isBalanceAvailable(amt,balance))
		{
		balance = balance - amt;
		setBalance(balance);
		}
		else
			System.out.println("You dont have sufficient balance");
	}
	
	private boolean isBalanceAvailable(double amt, double balance) {
		// TODO Auto-generated method stub
		
		if(balance-500 < amt)
			return false;
		else
			return true;
	}

	public String toString(Account ac) {
		return "----------------------------------------------\nAccount Number : "+ac.getAccNum()+"\nAccount Name : "+ac.getName()+"\nAccount Balance : "+ac.getBalance();
	}
	
	
}
