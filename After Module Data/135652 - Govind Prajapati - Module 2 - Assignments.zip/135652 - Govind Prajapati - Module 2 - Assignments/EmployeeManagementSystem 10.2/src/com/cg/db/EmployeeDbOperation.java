package com.cg.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.eis.bean.Employee;


public class EmployeeDbOperation {

	public void getAllEmployee() throws IOException, SQLException{
		 
		Connection con = DbUtil.getConnection();
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * From Employees");
		while(rs.next())
		{
			System.out.println("Employee Details\n-------------------------------- \n\nId : "+rs.getInt(1)+
						"\nName : "+rs.getString(2)+
						"\nDesignation : "+rs.getString(3)+
						"\nInsurance Scheme: "+rs.getString(4)+
						"\nSalary : "+rs.getFloat(5)+"\n\n");
			
		}
		con.close();
	}
	
	public void insertDetails(Employee e) throws IOException, SQLException{
		 
		Connection con = DbUtil.getConnection();
				
		PreparedStatement pst = con.prepareStatement("Insert into Employees values(?,?,?,?,?)");

		pst.setInt(1,e.geteId());
		pst.setString(2, e.geteName());
		pst.setString(3, e.geteDesign());
		pst.setString(4, e.geteInsuraceScheme());
		pst.setFloat(5, (float) e.geteSalary());
		
		int r = pst.executeUpdate();
		System.out.println(r+" row inserted");
		
				con.close();
			}
	
	
}


