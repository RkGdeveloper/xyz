package com.cg.eis.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.db.EmployeeDbOperation;
import com.cg.eis.bean.Employee;

public class UserInteraction {

	
	Scanner sc = new Scanner(System.in);
	EmployeeDbOperation edo = new EmployeeDbOperation();
	UserDetails ud = new UserDetails();
	
	public static void main(String[] args) throws IOException, SQLException {
		
		UserInteraction ui = new UserInteraction();
		
		ui.UserChoice();
		
	}
	
	
	void UserChoice() throws IOException, SQLException
	{

		do{
		System.out.println("Enter Your Choice: "
				+ "\n 1.Get All Employee"
				+ "\n 2.Insert Employee  Details"				
				+ "\n 3.Exit");
		int choice = sc.nextInt();
		
		
		switch(choice)
		{
		case 1:
			edo.getAllEmployee();
		break;
		case 2:
			ud.acceptEmployeeDetails();
		break;
		default:
				System.out.println("Choose Proper Operation");
		
		}
		
		System.out.println("Do you want to continue.....Y/N");
		char in = sc.next().charAt(0);
		
		if(in == 'n' || in == 'N')
			break;
		}while(true);
		
		System.out.println("Thank You");
	}
	
}


class UserDetails
{
	Scanner sc = new Scanner(System.in);
	EmployeeDbOperation edo = new EmployeeDbOperation();

	void acceptEmployeeDetails() throws IOException, SQLException
	{
		
		System.out.println("Enter number of Employee to Enter");
		int n = sc.nextInt();
	
		for(int i = 0;i<n;i++)
		{
		sc.nextLine();
		System.out.println("Enter Employee Details :");
		System.out.println("Enter Employee Name ");
		String eName = sc.nextLine();
		System.out.println("Enter Employee Designation ");
		String eDesign = sc.nextLine();
		System.out.println("Enter Employee Salary");
		double eSalary = sc.nextDouble();
		Employee emp =  new Employee(eName,eDesign,eSalary);
			edo.insertDetails(emp);
		
		}
		
	}
	
}
