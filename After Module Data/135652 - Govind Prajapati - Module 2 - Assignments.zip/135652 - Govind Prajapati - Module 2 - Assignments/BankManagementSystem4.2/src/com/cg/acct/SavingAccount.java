package com.cg.acct;

public class SavingAccount extends Account {

	static final int minBalance = 500;
	
	
	public  void deposite(double amt){
		balance = balance +amt;
		setBalance(balance);
	}
	public  void withdraw(double amt){

		if(isBalanceAvailable(amt,balance))
		{
		balance = balance - amt;
		setBalance(balance);
		}
		else
			System.out.println("You dont have sufficient balance");
	}
	public  boolean isBalanceAvailable(double amt, double balance){
		
		if(balance-minBalance < amt)
			return false;
		else
			return true;
	}
}
