package com.cg.acct;

public class CurrentAccount extends Account{
	
	static final int overDraftLimit = 10000;
	
	public  void deposite(double amt){
		setBalance(overDraftLimit);
	}
	
	public  void withdraw(double amt){

		if(isBalanceAvailable(amt,balance))
		{
		balance = balance - amt;
		setBalance(balance);
		}
		else
			System.out.println("Amount is more than Over Draft Limit");
	}
	
	public  boolean isBalanceAvailable(double amt, double balance){
		
		if(getBalance() < amt)
			return false;
		else
			return true;
	}
}
