package com.cg.enquirymngmt.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.enquirymngmt.bean.EnquiryDetails;
import com.cg.enquirymngmt.dao.EnquiryImpl;
import com.cg.enquirymngmt.dao.IEquiryDao;

public class EnquiryServiceImpl implements IEnquirService{

	IEquiryDao ied = new EnquiryImpl();
	
	@Override
	public EnquiryDetails getEnquiryById(int e_id) throws IOException, SQLException {
		// TODO Auto-generated method stub

		EnquiryDetails ed = new EnquiryDetails();
		ed = ied.getEnquiryById(e_id);
		
	return ed;
	
	}

	@Override
	public ArrayList<EnquiryDetails> getAllEnquiry() throws IOException, SQLException {
		return ied.getAllEnquiry();
	}

	
	@Override
	public int insertEnquiry(EnquiryDetails ed) throws SQLException, IOException {
		return ied.insertEnquiryDao(ed);
	}

	@Override
	public boolean checkIsEmpty(String input) {
		
		String pat = "[A-Z]{1}[A-Za-z]{1,}";
		
		if(input.isEmpty())
		{
			System.out.println("Input Cannot be empty");
			return false;
		}
		else if(Pattern.matches(pat, input))			
			return true;
		else
		{
			System.out.println("1st Letter must be Capital Letter Minimum 2");
			return false;
		}
	}

	@Override
	public boolean checkPhoneNo(String phone) {
		
		String pat = "[0-9]{10}";
		if(phone.isEmpty())
		{
			System.out.println("Input Cannot be empty");
			return false;
		}
		else if(Pattern.matches(pat, phone))
			return true;
		else
		{
			System.out.println("Phone number must have 10 digits");
			return false;
		}
	}

}
