package com.cg.enquirymngmt.exceptions;

public class EnquiryManagementException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	int en_id;
	public EnquiryManagementException(int e_id) {
		
		en_id = e_id;
	}
	@Override
	public String toString() {
		return "EnquiryManagementException : " + en_id + " does not exist in Database";
	}
	
	
}
