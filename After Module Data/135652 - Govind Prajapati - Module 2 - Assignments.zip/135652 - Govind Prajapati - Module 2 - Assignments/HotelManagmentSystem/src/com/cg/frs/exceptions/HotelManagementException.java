package com.cg.frs.exceptions;

public class HotelManagementException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	int data ;
	public HotelManagementException(int d) {
		//System.out.println("in Exception");
		data = d;
	}
	@Override
	public String toString() {
		return "HotelManagementException: This Hotel Id = " + data + " does not exist in database";
	}
	
	

}
