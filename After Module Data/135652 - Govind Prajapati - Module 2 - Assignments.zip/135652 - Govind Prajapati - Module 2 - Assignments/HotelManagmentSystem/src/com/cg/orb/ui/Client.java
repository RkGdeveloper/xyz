package com.cg.orb.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.frs.exceptions.HotelManagementException;
import com.cg.orb.dto.RoomRegistrationDTO;
import com.cg.orb.service.IRoomRegistrationService;
import com.cg.orb.service.RoomRegistrationServiceImpl;


public class Client {
	Logger log = Logger.getRootLogger();
	
	Client(){
		
		
		PropertyConfigurator.configure("log4j.properties");
	
		log.info("Program started");
	}
	
	
	Scanner sc = new Scanner(System.in);
	public static void main(String[] args)  {
		
		Client c =  new Client();
		
				c.userChoice();
			
		
	}
	
	
	void userChoice(){
		while(true)
		{
		System.out.println("==============\n1.Booking Room\n2.Exit\n=============");
		int choice = sc.nextInt();
		
			switch(choice){
			case 1: 
				try {
					bookRoom();
				} catch (IOException | SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					System.out.println(e.getMessage());
					log.error(e.getMessage());
				}
			
		
			break;
			case 2:
				{
				System.out.println("ThankYou..... Visit Again....");
				log.info("Exit from Application");
				System.exit(0);
				}
		}	
		}
	}

	private void bookRoom() throws IOException, SQLException {
	
		
		IRoomRegistrationService irs =new RoomRegistrationServiceImpl();
		ArrayList<Integer> hotel_ids = new ArrayList<Integer>(); 
		hotel_ids = irs.getAllOwnerIds();
		
		
		System.out.println("Existing HotelOwner IDS Are:-"+hotel_ids);
		System.out.println("Please enter your hotel owner id from above list: ");
		int h_id = sc.nextInt();
		try {
			if(irs.checkHotelId(h_id))
			{
			
			System.out.println("Select room type Type (1-1AC, 2-2NON-AC):");
			int roomType = sc.nextInt();
				if(irs.checkRoomTYpe(roomType))
				{
			System.out.println("Enter room area in sq. ft.: ");
			int area = sc.nextInt();
					if(irs.checkIsEmpty(area)){
			System.out.println("Enter desired rent amount Rs: ");
			double rentAmt = sc.nextDouble();
						if(irs.checkAmt(rentAmt))
						{
			System.out.println("Enter desired paid amount Rs: ");
			double paidAmt = sc.nextDouble();
							if(irs.checkAmt(paidAmt) && irs.checkRentAndPaidAmt(rentAmt,paidAmt))
							{
							RoomRegistrationDTO rd = new RoomRegistrationDTO(h_id, roomType, area, rentAmt, paidAmt);		
							
							RoomRegistrationDTO roomReg = irs.registerRoom(rd);
							
							System.out.println("Room successfully registered. Room no:<"+roomReg.getRoomNo()+">");
							}
						}
					}
				}
			}
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e);
			log.error(e);
		}
		}
	}
	
		
	

