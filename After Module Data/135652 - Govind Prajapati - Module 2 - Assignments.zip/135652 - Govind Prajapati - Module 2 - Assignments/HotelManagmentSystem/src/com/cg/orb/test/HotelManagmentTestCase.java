package com.cg.orb.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.frs.dao.IRoomRegistrationDAO;
import com.cg.frs.dao.RoomRegistrationDAOImpl;
import com.cg.orb.dto.RoomRegistrationDTO;

public class HotelManagmentTestCase {


	static IRoomRegistrationDAO ird = null;
	static RoomRegistrationDTO rd = null;
@BeforeClass

	public static void initialize() 
	{
	System.out.println("Hello ");
	ird = new RoomRegistrationDAOImpl();
	rd = new RoomRegistrationDTO();
	}

@Test
public void testData(){
	rd.setHotelId(1);
	rd.setRoomType(2);
	rd.setRoomArea(850);
	rd.setRentAmt(2500);
	rd.setPaidAmt(25000);
}

@Test
public void testAddDetails()   {
		try {
			assertNotNull(ird.registerRoom(rd));
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

@Test
public void testGetDetails() {
	try {
		assertNotNull(ird.getAllOwnerIds());
	} catch (IOException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
