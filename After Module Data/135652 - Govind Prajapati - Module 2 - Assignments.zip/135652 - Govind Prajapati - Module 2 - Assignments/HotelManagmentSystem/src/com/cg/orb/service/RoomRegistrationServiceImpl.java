package com.cg.orb.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dao.IRoomRegistrationDAO;
import com.cg.frs.dao.RoomRegistrationDAOImpl;
import com.cg.frs.exceptions.HotelManagementException;
import com.cg.orb.dto.RoomRegistrationDTO;

public class RoomRegistrationServiceImpl implements IRoomRegistrationService{

	Logger log = Logger.getRootLogger();
	public RoomRegistrationServiceImpl()
	{
		
		PropertyConfigurator.configure("log4j.properties");
	
		log.info("In Service");
	}
	
	
	
	
	IRoomRegistrationDAO ird = new RoomRegistrationDAOImpl();
	
	ArrayList<Integer> al = new ArrayList<Integer>();
	
	@Override
	public RoomRegistrationDTO registerRoom(RoomRegistrationDTO flat) throws SQLException, IOException {
		return ird.registerRoom(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		
		try {
			al = ird.getAllOwnerIds();
			log.info("Called getAllOwnerIds()");
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return al;
	}

	
	public boolean checkIsEmpty(int in){
		String pat = "[0-9]{1,8}";

		String input = String.valueOf(in);
		
		if(input.isEmpty())
		{
			System.out.println("Room Area cannot be empty");
			return false;
		}
		else if(!Pattern.matches(pat, input))
		{
			System.out.println("Input must have 8 digits between 0-9");
			return false;
		}
		else
			return true;
	}
	
	
	public boolean checkHotelId(int hotelId) throws HotelManagementException{
	 if(!al.contains(hotelId))
		{
			//System.out.println("Hotel Id does not exist");
			throw new HotelManagementException(hotelId);
		}
		else 
			return true;
	}

	@Override
	public boolean checkRoomTYpe(int rt) {
		// TODO Auto-generated method stub
		if(rt == 1 || rt == 2)
			return true;
		else
		{
			System.out.println("Room Type must be 1 or 2");
			return false;
		}
	}

	@Override
	public boolean checkAmt(double amt) {
		
		if(amt < 0)
		{
			System.out.println("Amount cannot be empty");
			return false;
		}
		
		else
			return true;
		
	}

	@Override
	public boolean checkRentAndPaidAmt(double rentAmt, double paidAmt) {
		// TODO Auto-generated method stub
		
		if(rentAmt > paidAmt)
		{	
			System.out.println("Paid Amount cannot be less than Rent Amount");
		return false;
		}
		else
			return true;
	}

	

}
