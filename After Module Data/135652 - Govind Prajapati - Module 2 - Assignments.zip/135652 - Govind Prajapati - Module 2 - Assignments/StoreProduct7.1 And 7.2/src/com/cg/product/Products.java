package com.cg.product;

import java.util.ArrayList;

import java.util.Scanner;

public class Products {

	public static void main(String[] args) {
		
		ProductDetails pd = new ProductDetails();
		pd.acceptAndSort();
	}
	
}


class ProductDetails
{
	Scanner sc =new Scanner(System.in);
	
	
	void acceptAndSort()
	{
		
		// for 7.1
		
		
/*	System.out.println("Enter number of Product");
	int n = sc.nextInt();

	String s[] = new String[n];
	System.out.println("Enter Products Name : ");
	for(int i=0;i<n;i++)
		s[i] = sc.next();
	Arrays.sort(s);
	
	System.out.println("Sorted Product Names are");
	for(int i=0;i<n;i++)
		System.out.println(s[i]);
	
	System.out.println("Sorted List is : ");
	for(String str:s) // using for each loop 1.5 features
	{
		System.out.println(str);
	}
	
	*/
	
		// for 7.2
		
	System.out.println("Enter number of Product");
	int n = sc.nextInt();
	
	sc.nextLine();
	
	ArrayList<String> al = new ArrayList<String>();
	System.out.println("Enter Products Name : ");
	for(int i=0;i<n;i++)
		al.add(sc.nextLine());
	
	
	//Collections.sort(al);
	
	System.out.println("Sorted List is : ");
	
	for(String str:al) // using for each loop 1.5 features
	{
		System.out.println(str);
	}
	
	
	}
	
}