package com.cg.customercomplaint.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.customercomplaint.dto.CustomerComplaint;

@Repository
@Transactional
public class CustomerComplaintDAOImpl implements ICustomerComplaintDAO{

	
	@PersistenceContext
	private EntityManager entityManager;

	
	@Override
	public CustomerComplaint addComplaint(CustomerComplaint compDetails) {
		
		if(compDetails!=null){
			entityManager.persist(compDetails);
			entityManager.flush();
			System.out.println("data inserted");
		}	
		return compDetails;
	}


	@Override
	public CustomerComplaint getComplaintDetailsById(int compId) {
		Query q = entityManager.createNamedQuery("getById");
		q.setParameter("compId", compId);
		CustomerComplaint compDetails = new CustomerComplaint(); 
		
		
		compDetails =  (CustomerComplaint) q.getSingleResult();
		System.out.println("in Dao"+compDetails);
		
		
		return compDetails;
	}

	
	
}
