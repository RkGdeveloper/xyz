package com.cg.customercomplaint.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.customercomplaint.dto.CustomerComplaint;
import com.cg.customercomplaint.service.ICustomerComplaintService;



@Controller
@RequestMapping("/complaint")
public class CustomerController {

	@Autowired
	private ICustomerComplaintService compService;
	
	
	public ICustomerComplaintService getCompService() {
		return compService;
	}


	public void setCompService(ICustomerComplaintService compService) {
		this.compService = compService;
	}

	@RequestMapping("/checkStatus.obj")
	public String prepareCheckStatusPage(Model m){
		m.addAttribute("pojoForId",new CustomerComplaint());
		m.addAttribute("compDetails",new CustomerComplaint());
		
			return "pages/checkStatus";
	}
	
	
	@RequestMapping("/checkIdStatus")
	public String getComplaintDetailsById(@ModelAttribute("complaintDetails")@Valid CustomerComplaint compDetails,BindingResult result,Model m){
		int compId = compDetails.getComplaintId();
		try{
		compDetails = compService.getComplaintDetailsById(compId);
		}
		catch(Exception e){
			//throw new CustomerComplaintException("Complaint Id does not exist in Database.. Please Enter valid Complaomt Id");
			m.addAttribute("Exeception","Complaint Id does not exist in Database.. Please Enter valid Complaomt Id");
			return "pages/ComplaintException";
		}
		
		
		System.out.println("in Controller"+compDetails);
		
		m.addAttribute("pojoForId",new CustomerComplaint());
		m.addAttribute("compDetails",compDetails);
		return "pages/checkStatus"; 
	}
}
