package com.cg.customercomplaint.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.customercomplaint.dto.CustomerComplaint;
import com.cg.customercomplaint.service.ICustomerComplaintService;

@Controller
public class HomeController {

	

	@Autowired
	private ICustomerComplaintService compService;
	
	
	public ICustomerComplaintService getCompService() {
		return compService;
	}


	public void setCompService(ICustomerComplaintService compService) {
		this.compService = compService;
	}


	
	
	
	@RequestMapping("/index")
	public String goToIndex(HttpServletRequest req, Model m){
		
		m.addAttribute("appTitle",req.getServletContext().getServletContextName());
		
		Map<Integer,String> category = new LinkedHashMap<Integer,String>();
		category.put(1, "Internet Banking");
		category.put(2, "General Banking");
		category.put(3, "Others");
		
		m.addAttribute("complaintDetails",new CustomerComplaint());
		m.addAttribute("categorySet",category);
		
		
		return "index";
	}
	
	
	@RequestMapping("/addComplaint")
	public String addComplaintDetails(HttpServletRequest req,@ModelAttribute("complaintDetails")@Valid CustomerComplaint compDetails,BindingResult result,Model m){
		if(result.hasErrors()){
			System.out.println("in validation");
			
			m.addAttribute("appTitle",req.getServletContext().getServletContextName());
			
			Map<Integer,String> category = new LinkedHashMap<Integer,String>();
			category.put(1, "Internet Banking");
			category.put(2, "General Banking");
			category.put(3, "Others");
			
			m.addAttribute("categorySet",category);
			
			return "index";
		}
		else
		{
			System.out.println("Details are"+compDetails);
			if(compDetails.getCategory().equals("1")){
				compDetails.setCategory("Internet Banking");
				compDetails.setPriority("High");
				compDetails.setStatus("Open");
			}
			else if(compDetails.getCategory().equals("2")){
				compDetails.setCategory("General Banking");
				compDetails.setPriority("Medium");
				compDetails.setStatus("Open");
			}
			else{
				compDetails.setCategory("Others");
				compDetails.setPriority("Low");
				compDetails.setStatus("Open");
			}
				
			
			CustomerComplaint comDetails = compService.addComplaint(compDetails);
			
			System.out.println("After"+comDetails);
			
			
			m.addAttribute("compDetails",comDetails);
			return "pages/SuccessPage";
		}
	}
}
