package com.cg.customercomplaint.service;

import com.cg.customercomplaint.dto.CustomerComplaint;

public interface ICustomerComplaintService {

	CustomerComplaint addComplaint(CustomerComplaint compDetails);

	CustomerComplaint getComplaintDetailsById(int compId);
}
