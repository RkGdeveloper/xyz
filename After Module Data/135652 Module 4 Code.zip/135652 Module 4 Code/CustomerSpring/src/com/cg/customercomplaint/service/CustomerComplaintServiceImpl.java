package com.cg.customercomplaint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customercomplaint.dao.ICustomerComplaintDAO;
import com.cg.customercomplaint.dto.CustomerComplaint;


@Service
public class CustomerComplaintServiceImpl implements ICustomerComplaintService{

	@Autowired
	private ICustomerComplaintDAO compDao;
	

	public ICustomerComplaintDAO getCompDao() {
		return compDao;
	}


	public void setCompDao(ICustomerComplaintDAO compDao) {
		this.compDao = compDao;
	}


	@Override
	public CustomerComplaint addComplaint(CustomerComplaint compDetails) {
		return compDao.addComplaint(compDetails);
	}


	@Override
	public CustomerComplaint getComplaintDetailsById(int compId) {
		return compDao.getComplaintDetailsById(compId);
	}
	
	
}
