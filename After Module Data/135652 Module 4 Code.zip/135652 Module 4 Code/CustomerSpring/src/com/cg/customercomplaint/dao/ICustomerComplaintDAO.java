package com.cg.customercomplaint.dao;

import com.cg.customercomplaint.dto.CustomerComplaint;

public interface ICustomerComplaintDAO {

	CustomerComplaint addComplaint(CustomerComplaint compDetails);

	CustomerComplaint getComplaintDetailsById(int compId);

}
