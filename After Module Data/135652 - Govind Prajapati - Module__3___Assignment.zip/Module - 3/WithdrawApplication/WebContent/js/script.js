function validate()
{
	var acNum = document.forms[0].accountNum.value;
	var acType = document.forms[0].account.value;
	var amount = document.forms[0].withdrawAmt.value;
	
	if(acNum == ""){
			alert('please select Account Number'); 
			return false;
		}
	
	else if(acType == ""){
			alert('please select Account Type'); 
			return false;
		}
	
	else if(amount == "" || amount < 0){
		alert('invalid Amount');
		return false;
	}
	
	else
		return true;
	}