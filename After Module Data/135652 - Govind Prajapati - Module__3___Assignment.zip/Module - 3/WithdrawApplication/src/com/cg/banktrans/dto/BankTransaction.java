package com.cg.banktrans.dto;

public class BankTransaction {

	private long transId;
	private long accNumber;
	private String accType;
	private int withdraw_amt;
	private int balance;
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}
	public int getWithdraw_amt() {
		return withdraw_amt;
	}
	public void setWithdraw_amt(int withdraw_amt) {
		this.withdraw_amt = withdraw_amt;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankTransaction [transId=" + transId + ", accNumber="
				+ accNumber + ", accType=" + accType + ", withdraw_amt="
				+ withdraw_amt + ", balance=" + balance + "]";
	}
	
	
}
