package com.cg.banktrans.service;

import java.util.ArrayList;

import com.cg.banktrans.dto.BankTransaction;
import com.cg.banktrans.exception.BankTransactionException;

public interface IBankTransactionService {

	ArrayList<Integer> getAllAccount() throws BankTransactionException;

	BankTransaction updateBalance(BankTransaction bt) throws BankTransactionException;

}
