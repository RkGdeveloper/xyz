package com.cg.banktrans.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.jboss.logging.Logger;

import com.cg.banktrans.dbconfig.DbUtil;
import com.cg.banktrans.dto.BankTransaction;
import com.cg.banktrans.exception.BankTransactionException;

public class BankTransactionDAOImpl implements IBankTransactionDAO {

	
	Logger log = Logger.getLogger(BankTransactionDAOImpl.class);
	
	@Override
	public ArrayList<Integer> getAllAccount() throws BankTransactionException {
		ArrayList<Integer> accList = new ArrayList<Integer>();
		Connection con = DbUtil.getConnection();
		try {
			Statement st = con.createStatement();
			String sql = "Select Acco from account_details";
		
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				accList.add(rs.getInt(1));
			}
			
			
			
		} catch (SQLException e) {
			//e.printStackTrace();
			throw new BankTransactionException(e.getMessage());
		}
		
		
		return accList;
		
	}

	@Override
	public BankTransaction updateBalance(BankTransaction bt) throws BankTransactionException {
	
		Connection con = DbUtil.getConnection();
		
			PreparedStatement pst;
			try {
				pst = con.prepareStatement("insert into account_trans values(trans_seq.nextval,?,?,SYSDATE)");
				pst.setLong(1, bt.getAccNumber());
				pst.setInt(2,bt.getWithdraw_amt());
				int nr = pst.executeUpdate();
				System.out.println(nr+" row inserted");
				
				log.info(nr+" row inserted");
			
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				Statement st = con.createStatement();
				ResultSet rst = st.executeQuery("select trans_seq.currval from dual");
				while(rst.next()){
					bt.setTransId(rst.getInt(1));
				}
				
				
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				//e2.printStackTrace();
				throw new BankTransactionException(e2.getMessage());
				
			}
			
			
			PreparedStatement update=null;
			try {
				pst = con.prepareStatement("update account_details set balance = balance - ? where accNo = ?");
				pst.setInt(1, bt.getWithdraw_amt());
				pst.setLong(2,bt.getAccNumber());
				int nr = pst.executeUpdate();
				
				System.out.println(nr+" row updated");
			
			
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
				throw new BankTransactionException(e1.getMessage());
				
			}
			
			
			
		String getAccBalance = "select balance from account_details where accno = ?";
	
		try {
			PreparedStatement ps = con.prepareStatement(getAccBalance);
			ps.setLong(1, bt.getAccNumber());
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				bt.setBalance(rs.getInt(1));
			}
			
			
		} catch (SQLException e) {
			//e.printStackTrace();
			throw new BankTransactionException(e.getMessage());
			
		}
		
		
		return bt;
	}

}
