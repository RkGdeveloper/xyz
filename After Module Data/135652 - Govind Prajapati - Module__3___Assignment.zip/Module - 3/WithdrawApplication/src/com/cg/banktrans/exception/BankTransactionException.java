package com.cg.banktrans.exception;

public class BankTransactionException extends Exception{

	public BankTransactionException(String message){
		super(message);
	}
	
}
