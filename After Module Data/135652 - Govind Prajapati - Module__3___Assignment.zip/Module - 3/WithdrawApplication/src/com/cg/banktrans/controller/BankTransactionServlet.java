package com.cg.banktrans.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.banktrans.dto.BankTransaction;
import com.cg.banktrans.exception.BankTransactionException;
import com.cg.banktrans.service.BankTransactionServiceImpl;
import com.cg.banktrans.service.IBankTransactionService;




@WebServlet("*.obj")
public class BankTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	IBankTransactionService its = new BankTransactionServiceImpl();
    
    public BankTransactionServlet() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	
	}
	
	String target = null;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String path = request.getServletPath();
		switch(path){
		
		case "/withdraw.obj":{
			ArrayList<Integer> accNo;
			
			try {
				accNo = its.getAllAccount();
				HttpSession session = request.getSession(true);
				session.setAttribute("acList", accNo);
				target = "Transaction.jsp";

			} catch (BankTransactionException e) {
			
				String error = e.getMessage();
				request.setAttribute("err", error);
				target = "error.jsp";
			}
		}
		break;
		
		
		case "/withdrawAmt.obj":{
			long accNum = Long.parseLong(request.getParameter("accountNum"));
			String accType = request.getParameter("account");
			int wAmt = Integer.parseInt(request.getParameter("txtWithdrawAmt"));
			
			BankTransaction bt = new BankTransaction();
			bt.setAccNumber(accNum);
			bt.setWithdraw_amt(wAmt);
			bt.setAccType(accType);
			
			try {
				bt = its.updateBalance(bt);
				System.out.println(bt);
				HttpSession session = request.getSession(false);
				session.setAttribute("bean", bt);	
				target = "SuccessResult.jsp";
				
			} catch (BankTransactionException e) {
				String error = e.getMessage();
				request.setAttribute("err", error);
				target = "error.jsp";
			}
			
		
			
		}
		break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
		}

}
