package com.cg.banktrans.dbconfig;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DbUtil {

	
	static Connection con;
	
	public static Connection getConnection(){
		
		try{
		
		InitialContext ic;
			ic = new InitialContext();
		
		DataSource ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
		con = ds.getConnection();
		}
		catch(NamingException e){
			System.out.println(e.getMessage());
		}
		catch(SQLException e){

			System.out.println(e.getMessage());
		}
		
		return con;
	} 
	
}
