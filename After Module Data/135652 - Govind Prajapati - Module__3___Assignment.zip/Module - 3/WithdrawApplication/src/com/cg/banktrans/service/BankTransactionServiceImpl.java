package com.cg.banktrans.service;

import java.util.ArrayList;

import com.cg.banktrans.dao.BankTransactionDAOImpl;
import com.cg.banktrans.dao.IBankTransactionDAO;
import com.cg.banktrans.dto.BankTransaction;
import com.cg.banktrans.exception.BankTransactionException;

public class BankTransactionServiceImpl implements IBankTransactionService{

	IBankTransactionDAO itd = new BankTransactionDAOImpl();
	
	@Override
	public ArrayList<Integer> getAllAccount() throws BankTransactionException {
		return itd.getAllAccount();
	}

	@Override
	public BankTransaction updateBalance(BankTransaction bt) throws BankTransactionException {
		
		return itd.updateBalance(bt);
	}

	
	
	
}
