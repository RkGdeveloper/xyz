package com.cg.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bank.bean.Customer;
import com.cg.bank.dbutil.DbUtil;

public class BankManagmentDAOImpl implements IBankManagmentDAO{

	public BankManagmentDAOImpl(){}
	
	@Override
	public int addCustomerDetails(Customer c) {
		int nrows = 0;
		Connection con = DbUtil.getConnection();
			try {
				PreparedStatement ps = con.prepareStatement("insert into bankcustomerdetails values(bank_seq.nextval,?,?,?,1000)");

				ps.setString(1, c.getCustName());
				ps.setLong(2, c.getPhoneNumber());
				ps.setString(3, c.getCustPwd());	
				nrows = ps.executeUpdate();
				
				
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery("select bank_seq.currval from dual");
				while(rs.next()){
					c.setCustId(rs.getInt(1));
				}
			nrows = c.getCustId();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
		return nrows;
	}

	@Override
	public ArrayList<Customer> getAllCustomerDetails() {
		Connection con = DbUtil.getConnection();
		ArrayList<Customer> arrCust = new ArrayList<Customer>();
		Customer c;
		try {
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery("Select * from bankcustomerdetails");
			
			while(rs.next()){
				
				c = new Customer();
				c.setCustId(rs.getInt(1));
				c.setCustName(rs.getString(2));
				c.setPhoneNumber(rs.getLong(3));
				c.setCustPwd(rs.getString(4));
				c.setBalance(rs.getDouble(5));
				arrCust.add(c);
				System.out.println("Data Added in arraylist");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return arrCust;
	}

	@Override
	public Customer getCustomerById(int cid) {
		Connection con = DbUtil.getConnection();
		Customer c = new Customer();
		try {
			
			PreparedStatement ps = con.prepareStatement("Select * from bankcustomerdetails where custId = ?");

			ps.setInt(1, cid);
		
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				
				c.setCustId(rs.getInt(1));
				c.setCustName(rs.getString(2));
				c.setPhoneNumber(rs.getLong(3));
				c.setCustPwd(rs.getString(4));
				c.setBalance(rs.getDouble(5));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return c;
	}

	@Override
	public double updateCustomerBalance(int custId, double am) {
		
		Connection con = DbUtil.getConnection();
		double rAmt=0;
		try {
			
			PreparedStatement ps = con.prepareStatement("Update bankcustomerdetails set balance = balance - ? where custId = ?");

			ps.setDouble(1, am);
			ps.setInt(2, custId);
		
			int r = ps.executeUpdate();
			if(r>0){
				PreparedStatement pst = con.prepareStatement("Select balance from bankcustomerdetails where custId = ?");
				pst.setInt(1, custId);
				ResultSet rss = pst.executeQuery();
				while(rss.next()){
					rAmt = rss.getDouble(1);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rAmt;
	}

}
