package com.cg.bank.dao;

import java.util.ArrayList;

import com.cg.bank.bean.Customer;

public interface IBankManagmentDAO {

	public int addCustomerDetails(Customer c);

	public ArrayList<Customer> getAllCustomerDetails();

	public Customer getCustomerById(int cid);

	public double updateCustomerBalance(int custId, double am);
	
}
