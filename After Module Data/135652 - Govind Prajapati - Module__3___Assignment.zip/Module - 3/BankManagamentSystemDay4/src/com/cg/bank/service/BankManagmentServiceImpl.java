package com.cg.bank.service;


import java.util.ArrayList;

import com.cg.bank.bean.Customer;
import com.cg.bank.dao.BankManagmentDAOImpl;
import com.cg.bank.dao.IBankManagmentDAO;


public class BankManagmentServiceImpl implements IBankManagmentService {

	
	IBankManagmentDAO ied = new BankManagmentDAOImpl();
	@Override
	public int addCustomerDetails(Customer c) {
		//Call DAO layer Method
		
		return ied.addCustomerDetails(c);
	}
	@Override
	public ArrayList<Customer> getCustomerDetails() {
		return ied.getAllCustomerDetails();
	}
	@Override
	public Customer getCustomerById(int cid) {
		return ied.getCustomerById(cid);
	}
	@Override
	public double updateCustomerAmt(int custId, double am) {
		// TODO Auto-generated method stub
		return ied.updateCustomerBalance(custId,am);
	}

}
