package com.cg.bank.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bank.bean.Customer;
import com.cg.bank.service.BankManagmentServiceImpl;
import com.cg.bank.service.IBankManagmentService;

@WebServlet("*.obj")
public class HomeServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter out = response.getWriter();
	int flag = 0;
	String target = null;
		String path = request.getServletPath();
		switch(path){
		
		
		case "/addDetails.obj":
		{
			response.sendRedirect("AddCustomer.jsp");
		}
		break;
		
		case "/getAllDetails.obj":
		{
			//flag = 1;
			IBankManagmentService ies = new BankManagmentServiceImpl();
			ArrayList<Customer> arrCust = new ArrayList<Customer>();
			
			arrCust = ies.getCustomerDetails();
			for(Customer c : arrCust)
			{
				System.out.println(c);

				//out.println(c);
			}
			
			HttpSession session = request.getSession(false);
			session.setAttribute("arCust", arrCust);
			
			target ="AllCustomerDetails.jsp";
			
		}
		break;
		
		case "/customer.obj":
			{
				
				Customer cust = new Customer();
				String cName = request.getParameter("txtCname");
				String cPhno = request.getParameter("txtPhno");
				String pass = request.getParameter("txtPass");
				String rePass = request.getParameter("txtRePass");
				
				if(!(pass.equals(rePass)))
				{
					flag = 1;
					RequestDispatcher rd = request.getRequestDispatcher("AddCustomer.html");
					rd.include(request, response);
					System.out.println("in password is not match");
					out.print("<font color='red'>Password and ReEnter Password must match......</font>");
				}
				else
				{
				cust.setCustName(cName);
				cust.setCustPwd(pass);
				long ph = Long.parseLong(cPhno);
				cust.setPhoneNumber(ph);
				
				//Call service layer method
				IBankManagmentService ies = new BankManagmentServiceImpl();
				int nr = ies.addCustomerDetails(cust);
				
				System.out.println(nr+"Id Successfully inserted");
				
				
				//out.print(nr+ "row inserted");
				
				
				if(nr > 0)
				{
					//out.print("<script>alert("+nr+"'Details inserted successfully')</script>");
					
					HttpSession session = request.getSession(true);
					String id = String.valueOf(nr);
					session.setAttribute("cId", id);
					
					target ="success.jsp";
					
					//out.print("your id is "+nr);
				}
				else
					//when you set password and re-password is blank then only error page will come
					target ="error.html";
				}
			}
		break;
		
		case "/getCustById.obj":
		{
			
			response.sendRedirect("RetrieveCustomerById.jsp");
			
		}
		break;
		
		
		case "/customerById.obj":
		{
			IBankManagmentService ies = new BankManagmentServiceImpl();
			//flag = 1;
			
			String cId = request.getParameter("txtCid");
			Customer c = new Customer();
			int cid = Integer.parseInt(cId); 
			c = ies.getCustomerById(cid);
			System.out.println(c);
			HttpSession session = request.getSession();
			
			session.setAttribute("cust", c);

			target = "CustomerById.jsp";
/*			RequestDispatcher rd = request.getRequestDispatcher("CustomerById.jsp");
			rd.forward(request, response);
			
*/			
			//out.println(c);
			
		}
		break;
		
		case "/logout.obj":
		{
			HttpSession session = request.getSession(false);
			session.invalidate();
			target = "RetrieveCustomerById.jsp";
		}
		break;
		
		case "/payAmt.obj":
		{
			String amt = request.getParameter("txtAmt");
			HttpSession session = request.getSession(false);

			Customer c = (Customer)session.getAttribute("cust");
			System.out.println("id is "+c.getCustId());
			System.out.println(amt);
			double am = Double.parseDouble(amt);
			IBankManagmentService ies = new BankManagmentServiceImpl();
			int id = c.getCustId();
			double remaining_amt = ies.updateCustomerAmt(id,am);
			session.setAttribute("remAmt", remaining_amt);
			target = "PayYourBill.jsp";
			
		}
		break;

		}
		
		
		if(flag == 0)
		{
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request,response);
	}
	
	

}
