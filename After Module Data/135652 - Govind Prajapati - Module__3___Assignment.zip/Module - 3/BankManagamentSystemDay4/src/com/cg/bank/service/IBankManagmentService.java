package com.cg.bank.service;

import java.util.ArrayList;

import com.cg.bank.bean.Customer;

public interface IBankManagmentService {

	int addCustomerDetails(Customer c);

	ArrayList<Customer> getCustomerDetails();

	Customer getCustomerById(int cid);

	double updateCustomerAmt(int custId, double am);
	
	
}
