package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SecondServletForUserInterface")
public class SecondServletForUserInterface extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request,response);
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		ServletContext context = getServletContext();
		
		String name = (String) context.getAttribute("username");
		String pass = (String) context.getAttribute("pwd");
		String email = (String) context.getAttribute("e_mail");
		String ph = (String) context.getAttribute("phno");
		
		
		PrintWriter out = response.getWriter(); 
		
		out.print("<html><body>"
				+ "<h1>User name : </h1>"+name
				+ "<h1>User Password : </h1>"+pass
				+ "<h1>User Email : </h1>"+email
				+ "<h1>User Phone : </h1>"+ph);

		
		
	}

}
