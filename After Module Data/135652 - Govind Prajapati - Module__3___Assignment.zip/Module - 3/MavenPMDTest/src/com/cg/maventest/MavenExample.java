package com.cg.maventest;


/*	Class Name 		: MavenExample
 * 	Date Modified 	: 10-10-2017
 * 	Author			: Govind Prajapati
 * 
 * 
 * **/

public class MavenExample {

	
	public static void main(String... args) {
		
		MavenExample mavEx = new MavenExample();
		mavEx.getEmpId();
	}
	
	void getEmpId(){
		int empId=123;
		System.out.println("Value is "+empId);

	}
	
}
