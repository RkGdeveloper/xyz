package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	HttpSession session= request.getSession(false);
	
	PrintWriter out = response.getWriter();
	String name = (String) session.getAttribute("uname");
	String desig = (String) session.getAttribute("des");
	String e_mail =(String) session.getAttribute("email");
	String ph = (String) session.getAttribute("phno");
	String depart = (String) session.getAttribute("dept");
	
	out.print("<html><body>");
	out.print(name+"<br/>"+desig+"<br/>"+e_mail+"<br/>"+ph+"<br/>"+depart);
	out.print("</body></html>");
	
	
	}

}
