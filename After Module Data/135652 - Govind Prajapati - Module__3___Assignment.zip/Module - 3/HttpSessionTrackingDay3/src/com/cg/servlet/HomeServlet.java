package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String name = request.getParameter("uname");
		String desig = request.getParameter("des");
		String e_mail = request.getParameter("email");
		String ph = request.getParameter("phno");
		String depart = request.getParameter("dept");
		
		HttpSession session = request.getSession();
		session.setAttribute("uname", name);
		session.setAttribute("des", desig);
		session.setAttribute("email", e_mail);
		session.setAttribute("phno", ph);
		session.setAttribute("dept", depart);
		
//		RequestDispatcher rd = request.getRequestDispatcher("WelcomeServlet");
		RequestDispatcher rd = request.getRequestDispatcher("Welcome.jsp");
		
		rd.forward(request, response);
	
	//	response.sendRedirect("welcome.jsp");
		
	}

}
