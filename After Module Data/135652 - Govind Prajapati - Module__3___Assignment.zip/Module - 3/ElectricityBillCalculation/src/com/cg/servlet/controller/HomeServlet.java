package com.cg.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.elecbill.bean.Customer;
import com.cg.elecbill.service.ElectricityBillServiceImpl;
import com.cg.elecbill.service.IElectricityBillService;

@WebServlet("*.obj")
public class HomeServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	//PrintWriter out = response.getWriter();
	
	String target = null;
		String path = request.getServletPath();
		switch(path){
		
		case "/customer.obj":
			{
				String consNum = request.getParameter("txtConsNum");
				String cName = request.getParameter("txtCname");
				String cEmail = request.getParameter("txtEmail");
				String cPhone = request.getParameter("txtPhno");
				
				int cn = Integer.parseInt(consNum);
				Customer cust = new Customer();
				cust.setConsumerNumber(cn);
				cust.setCustName(cName);
				cust.setCustEmail(cEmail);
				cust.setCustPhone(cPhone);
				
				//Call service layer method
				IElectricityBillService ies = new ElectricityBillServiceImpl();
				int nr = ies.addCustomerDetails(cust);
				
				System.out.println(nr+" row inserted");
				
				//out.print(nr+ "row inserted");
				
				//out.print("<script>alert('Details inserted successfully')</script>");
			
				if(nr > 0)
				{
					target ="success.html";
				}
				else
					target ="error.html";
			}
		break;
		}
		
		
		
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request,response);
	}
	
	

}
