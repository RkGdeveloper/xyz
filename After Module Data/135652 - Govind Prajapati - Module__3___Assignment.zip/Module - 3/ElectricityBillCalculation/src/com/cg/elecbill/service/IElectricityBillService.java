package com.cg.elecbill.service;

import com.cg.elecbill.bean.Customer;

public interface IElectricityBillService {

	int addCustomerDetails(Customer c);
	
	
}
