package com.cg.elecbill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.elecbill.bean.Customer;
import com.cg.elecbill.dbutil.DbUtil;

public class ElecticityBillDAOImpl implements IElectricityBillDAO{

	@Override
	public int addCustomerDetails(Customer c) {
		int nrows = 0;
		Connection con = DbUtil.getConnection();
			try {
				PreparedStatement ps = con.prepareStatement("insert into billdetails values(?,?,?,?)");
				ps.setInt(1, c.getConsumerNumber());
				ps.setString(2, c.getCustName());
				ps.setString(3, c.getCustEmail());
				ps.setString(4, c.getCustPhone());
				
				nrows = ps.executeUpdate();
				
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return nrows;
	}

}
