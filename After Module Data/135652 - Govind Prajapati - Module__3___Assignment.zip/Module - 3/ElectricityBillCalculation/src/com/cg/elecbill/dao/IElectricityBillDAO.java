package com.cg.elecbill.dao;

import com.cg.elecbill.bean.Customer;

public interface IElectricityBillDAO {

	public int addCustomerDetails(Customer c);
	
}
