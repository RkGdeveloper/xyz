package com.cg.elecbill.service;


import com.cg.elecbill.bean.Customer;
import com.cg.elecbill.dao.ElecticityBillDAOImpl;
import com.cg.elecbill.dao.IElectricityBillDAO;


public class ElectricityBillServiceImpl implements IElectricityBillService {

	
	IElectricityBillDAO ied = new ElecticityBillDAOImpl();
	@Override
	public int addCustomerDetails(Customer c) {
		//Call DAO layer Method
		
		return ied.addCustomerDetails(c);
	}

}
