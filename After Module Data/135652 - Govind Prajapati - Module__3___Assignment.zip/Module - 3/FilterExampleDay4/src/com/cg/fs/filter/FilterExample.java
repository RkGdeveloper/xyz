package com.cg.fs.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/FilterExample")
public class FilterExample implements Filter {

  public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		PrintWriter out = response.getWriter();
		String pass = request.getParameter("upass");
		if(pass.equals("admin"))
		{
			chain.doFilter(request, response);	
		}
		String name = request.getParameter("uname");
		if(name.equals("Govind"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("WelcomeServlet");
			rd.forward(request, response);
		}
		
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.include(request, response);
			out.println("<font color ='red'>Invalid Username</font>");
			
		}
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
