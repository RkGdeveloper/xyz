package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String name = request.getParameter("uname");
		String desig = request.getParameter("des");
		String e_mail = request.getParameter("email");
		String ph = request.getParameter("phno");
		//String depart = request.getParameter("dept");
		
		
		Cookie ck1 = new Cookie("uname", name);
		Cookie ck2 = new Cookie("des", desig);
		Cookie ck3 = new Cookie("email", e_mail);
		Cookie ck4 = new Cookie("ph", ph);
		
		response.addCookie(ck1);
		response.addCookie(ck2);
		response.addCookie(ck3);
		response.addCookie(ck4);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("WelcomeServlet");
//		RequestDispatcher rd = request.getRequestDispatcher("Welcome.jsp");
		
		rd.forward(request, response);
	
	//	response.sendRedirect("welcome.jsp");
		
	}

}
